Ya os gustaría que hubiese un premio. Pero no hay. 

Pasó por aquí el Juancar y se lo llevó a Abu Dabi.
